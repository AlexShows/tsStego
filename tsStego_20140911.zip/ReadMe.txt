tsStego.cpp
Released under the MIT License
------------------------------
 
A simple implementation of stegonography in C++
Uses the LodePNG library version 20140801 by Lode Vandevenne

Included in this zip file are:
------------------------------

ReadMe.txt - this file
  tsStego.exe - a binary compiled from the latest source on Sept. 8th, 2014
  irish_stamp.png - a public domain image useful for testing the binary
  example.txt - a sample text file for testing the binary

Usage examples:
---------------

  tsStego.exe encode example.txt irish_stamp.png cipher.png optionalpassword
	Encode the example.txt into irish_stamp.png, producing cipher.png
	with the contents of example.txt AES encrypted using optionalpassword.

  tsStego.exe decode cipher.png decoded.txt optionalpassword
	Decode decoded.txt from the cipher.png using the optionalpassword.